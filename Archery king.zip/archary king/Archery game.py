import pygame
from pygame import mixer
import random
import math

z = 1
x = 0
pygame.init()
# create the screen
screen = pygame.display.set_mode((800, 600))
# Create background
background = pygame.image.load('background.png')
# Background sound
mixer.music.load('backgroundsound.wav')
mixer.music.play(-1)
# create Title and icon
pygame.display.set_caption("Archery King")
icon = pygame.image.load('archery.png')
pygame.display.set_icon(icon)
# Player
playerImg = pygame.image.load('bow.png')
playerx = 370
playery = 480
playerx_change = 0
# Target
targetImg = []
targetx = []
targety = []
targetx_change = []
num_of_target = 2
for i in range(num_of_target):
    targetImg.append(pygame.image.load('target.png'))
    targetx.append(random.randint(0, 736))
    targety.append(40)
    targetx_change.append(z)

# Arrow
# Ready -arrow not visible on screen
# Aim-arrow visible on screen
arrowImg = pygame.image.load('arrow.png')
arrowx = 0
arrowy = 416
arrowx_change = 0
arrowy_change = 2
arrow_state = "ready"

# Score
score_value = 0
font = pygame.font.Font('freesansbold.ttf', 32)
textx = 10
texty = 10
# Level
level_value = 0
level_font = pygame.font.Font('freesansbold.ttf', 32)
level_textx = 350
level_texty = 10

# Game over text
over_font = pygame.font.Font('freesansbold.ttf', 64)


def show_score(x, y):
    score = font.render("score : " + str(score_value), True, (0, 0, 255))
    screen.blit(score, (x, y))


def show_level_score(x, y):
    level_score = font.render("Level : " + str(level_value), True, (0, 255, 255))
    screen.blit(level_score, (x, y))


def game_over_text():
    over_text = over_font.render("Game Over", True, (255, 0, 0))
    screen.blit(over_text, (210, 220))


def player(x, y):
    screen.blit(playerImg, (x, y))


def target(x, y, i):
    screen.blit(targetImg[i], (x, y))


def Aim_arrow(x, y):
    global arrow_state
    arrow_state = "Aim"
    screen.blit(arrowImg, (x, y))


def isembeded(targetx, targety, arrowx, arrowy):
    distance = math.sqrt((math.pow(targetx - arrowx, 2)) + (math.pow(targety - arrowy, 2)))
    if distance < 64:
        return True
    else:
        return False


# game loop
Running = True
while Running:
    # RGB-RED,GREEN,BLUE
    screen.fill((0, 0, 0))
    # Background image
    screen.blit(background, (0, 0))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            Running = False
        # Keystroke(Left or Right)
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                playerx_change = -5
            if event.key == pygame.K_RIGHT:
                playerx_change = 5
            if event.key == pygame.K_SPACE:
                if arrow_state is "ready":
                    # Arrow sound
                    arrow_sound = mixer.Sound('arrowsound.wav')
                    arrow_sound.play()
                    arrowx = playerx
                    Aim_arrow(playerx, arrowy)
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                playerx_change = 0
    # Player Movement
    playerx += playerx_change
    if playerx <= 0:
        playerx = 0
    elif playerx >= 736:
        playerx = 736
    # Target movement
    for i in range(num_of_target):
        targetx[i] += targetx_change[i]
        if targetx[i] <= 0:
            targetx_change[i] = z
        elif targetx[i] >= 672:
            targetx_change[i] = -z
        # collision
        embeded = isembeded(targetx[i], targety[i], arrowx, arrowy)
        if embeded:
            # Collision sound
            embeded_sound = mixer.Sound('embededsound.wav')
            embeded_sound.play()
            arrowy = 440
            arrow_state = "ready"
            score_value += 5
            for k in range(1, 100):
                if (score_value == 10 * k):
                    level_value += 1
                    # Level Speed
                    z += 0.2
                    for l in range(num_of_target):
                        targetx_change.append(z)

            targetx[i] = random.randint(0, 736)
            targety[i] = 40

        target(targetx[i], targety[i], i)
    # Arrow movement
        # Game Over
        if arrowy < 1:
            for j in range(num_of_target):
                targety[j] = 2000
            x = 5

    if arrowy <= 0:
        arrowy = 440
        arrow_state = "ready"
    if arrow_state is "Aim":
        Aim_arrow(arrowx, arrowy)
        arrowy -= arrowy_change
    if (x == 5):
        # game over sound
        game_over_sound = mixer.Sound('gameoversound.wav')
        game_over_sound.play()
        game_over_text()

    player(playerx, playery)
    show_score(textx, texty)
    show_level_score(level_textx, level_texty)
    pygame.display.update()
pygame.quit()
quit()
